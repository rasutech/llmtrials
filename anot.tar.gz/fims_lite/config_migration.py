#!/usr/bin/env python3
"""
Configuration Migration Utility for FIMS Lite

This utility helps migrate and validate configurations for different database types.
"""

import json
import sys
import argparse
import logging
from typing import Dict, Any, List
from pathlib import Path
import shutil
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ConfigMigration:
    """Configuration migration and validation utility"""
    
    def __init__(self):
        self.template_configs = {
            'oracle': {
                'database': {
                    'type': 'oracle',
                    'host': 'localhost',
                    'port': 1521,
                    'service_name': 'ORCL',
                    'username': 'your_username',
                    'password': 'your_password',
                    'default_schema': 'FIMS',
                    'connection_params': {
                        'encoding': 'UTF-8',
                        'nencoding': 'UTF-8',
                        'threaded': True
                    }
                }
            },
            'postgresql': {
                'database': {
                    'type': 'postgresql',
                    'host': 'localhost',
                    'port': 5432,
                    'database': 'fims_db',
                    'username': 'your_username',
                    'password': 'your_password',
                    'default_schema': 'public',
                    'connection_params': {
                        'application_name': 'FIMS_Lite'
                    }
                }
            },
            'informix': {
                'database': {
                    'type': 'informix',
                    'host': 'localhost',
                    'port': 9088,
                    'database': 'fims_db',
                    'username': 'your_username',
                    'password': 'your_password',
                    'default_schema': 'informix',
                    'connection_params': {
                        'autocommit': False
                    }
                }
            },
            'mysql': {
                'database': {
                    'type': 'mysql',
                    'host': 'localhost',
                    'port': 3306,
                    'database': 'fims_db',
                    'username': 'your_username',
                    'password': 'your_password',
                    'default_schema': 'fims_db',
                    'connection_params': {
                        'charset': 'utf8mb4',
                        'autocommit': False
                    }
                }
            },
            'sqlserver': {
                'database': {
                    'type': 'sqlserver',
                    'host': 'localhost',
                    'port': 1433,
                    'database': 'fims_db',
                    'username': 'your_username',
                    'password': 'your_password',
                    'default_schema': 'dbo',
                    'connection_params': {
                        'autocommit': False,
                        'timeout': 30
                    }
                }
            }
        }
    
    def create_database_config(self, db_type: str, output_file: str = 'database_config.json') -> bool:
        """Create database configuration file for specified database type"""
        if db_type not in self.template_configs:
            logger.error(f"Unsupported database type: {db_type}")
            logger.info(f"Supported types: {', '.join(self.template_configs.keys())}")
            return False
        
        try:
            # Load the full supported databases configuration
            with open('database_config.json', 'r') as f:
                base_config = json.load(f)
            
            # Create new config with selected database type
            new_config = {
                'database': self.template_configs[db_type]['database'],
                'supported_databases': base_config['supported_databases']
            }
            
            # Backup existing file if it exists
            output_path = Path(output_file)
            if output_path.exists():
                backup_file = f"{output_file}.backup.{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                shutil.copy2(output_file, backup_file)
                logger.info(f"Backed up existing config to: {backup_file}")
            
            # Write new configuration
            with open(output_file, 'w') as f:
                json.dump(new_config, f, indent=2)
            
            logger.info(f"Created {db_type} database configuration: {output_file}")
            logger.warning("Don't forget to update username, password, and connection details!")
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to create database configuration: {e}")
            return False
    
    def migrate_object_config(self, source_file: str, target_db_type: str, 
                             output_file: str = None) -> bool:
        """Migrate object configuration for a different database type"""
        try:
            with open(source_file, 'r') as f:
                config = json.load(f)
            
            # Update metadata
            if 'metadata' not in config:
                config['metadata'] = {}
            
            config['metadata']['database_type'] = target_db_type
            config['metadata']['migrated_on'] = datetime.now().isoformat()
            config['metadata']['source_file'] = source_file
            
            # Database-specific transformations
            config = self._transform_for_database(config, target_db_type)
            
            # Output file
            if output_file is None:
                output_file = f"object_config_{target_db_type}.json"
            
            # Backup existing file
            output_path = Path(output_file)
            if output_path.exists():
                backup_file = f"{output_file}.backup.{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                shutil.copy2(output_file, backup_file)
                logger.info(f"Backed up existing config to: {backup_file}")
            
            # Write migrated configuration
            with open(output_file, 'w') as f:
                json.dump(config, f, indent=2)
            
            logger.info(f"Migrated object configuration for {target_db_type}: {output_file}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to migrate object configuration: {e}")
            return False
    
    def _transform_for_database(self, config: Dict[str, Any], db_type: str) -> Dict[str, Any]:
        """Apply database-specific transformations to object configuration"""
        
        # PostgreSQL transformations
        if db_type == 'postgresql':
            # PostgreSQL is case-sensitive and prefers lowercase
            config = self._transform_case(config, 'lower')
        
        # MySQL transformations
        elif db_type == 'mysql':
            # MySQL can be case-sensitive depending on configuration
            # Keep original case but add notes
            for table_name, table_config in config.get('tables', {}).items():
                table_config['notes'] = table_config.get('notes', [])
                if isinstance(table_config['notes'], str):
                    table_config['notes'] = [table_config['notes']]
                table_config['notes'].append("MySQL: Check case sensitivity settings")
        
        # SQL Server transformations  
        elif db_type == 'sqlserver':
            # SQL Server typically uses [] for identifiers
            for table_name, table_config in config.get('tables', {}).items():
                table_config['identifier_quote'] = '['
                table_config['identifier_quote_end'] = ']'
        
        # Informix transformations
        elif db_type == 'informix':
            # Informix-specific settings
            for table_name, table_config in config.get('tables', {}).items():
                # Informix has specific data type mappings
                for field_name, field_config in table_config.get('fields', {}).items():
                    if field_config.get('type') == 'NVARCHAR2':
                        field_config['type'] = 'VARCHAR'
        
        return config
    
    def _transform_case(self, config: Dict[str, Any], case: str) -> Dict[str, Any]:
        """Transform table and field names to specified case"""
        if case == 'lower':
            transform_func = str.lower
        elif case == 'upper':
            transform_func = str.upper
        else:
            return config
        
        new_config = {
            'metadata': config.get('metadata', {}),
            'tables': {}
        }
        
        for table_name, table_config in config.get('tables', {}).items():
            new_table_name = transform_func(table_name)
            new_table_config = dict(table_config)
            new_table_config['table_name'] = new_table_name
            
            # Transform field names
            if 'fields' in new_table_config:
                new_fields = {}
                for field_name, field_config in new_table_config['fields'].items():
                    new_field_name = transform_func(field_name)
                    new_fields[new_field_name] = field_config
                new_table_config['fields'] = new_fields
            
            # Transform key names
            for key_type in ['primary_keys', 'unique_keys']:
                if key_type in new_table_config:
                    new_table_config[key_type] = [transform_func(key) for key in new_table_config[key_type]]
            
            # Transform relationship field names
            if 'relationships' in new_table_config:
                for rel_type in ['children', 'parents']:
                    if rel_type in new_table_config['relationships']:
                        for rel in new_table_config['relationships'][rel_type]:
                            if 'foreign_key' in rel:
                                rel['foreign_key'] = transform_func(rel['foreign_key'])
                            if 'local_key' in rel:
                                rel['local_key'] = transform_func(rel['local_key'])
                            if 'table' in rel:
                                rel['table'] = transform_func(rel['table'])
            
            new_config['tables'][new_table_name] = new_table_config
        
        return new_config
    
    def validate_config_compatibility(self, object_config: str, database_config: str) -> bool:
        """Validate that object and database configurations are compatible"""
        try:
            with open(object_config, 'r') as f:
                obj_config = json.load(f)
            
            with open(database_config, 'r') as f:
                db_config = json.load(f)
            
            # Check database type compatibility
            obj_db_type = obj_config.get('metadata', {}).get('database_type')
            db_type = db_config.get('database', {}).get('type')
            
            if obj_db_type and db_type and obj_db_type != db_type:
                logger.warning(f"Database type mismatch: object config expects '{obj_db_type}', database config is '{db_type}'")
                return False
            
            logger.info("Configuration compatibility check passed")
            return True
            
        except Exception as e:
            logger.error(f"Failed to validate configuration compatibility: {e}")
            return False
    
    def generate_requirements_txt(self, db_type: str, output_file: str = 'requirements_db.txt') -> bool:
        """Generate requirements.txt file for specific database type"""
        base_requirements = [
            'flask>=2.0.0',
            'python-dateutil>=2.8.0'
        ]
        
        db_requirements = {
            'oracle': ['cx_Oracle>=8.0.0'],
            'postgresql': ['psycopg2-binary>=2.8.0'],
            'informix': ['informixdb>=2.5.0'],
            'mysql': ['PyMySQL>=1.0.0'],
            'sqlserver': ['pyodbc>=4.0.0']
        }
        
        try:
            requirements = base_requirements + db_requirements.get(db_type, [])
            
            with open(output_file, 'w') as f:
                for req in requirements:
                    f.write(f"{req}\n")
            
            logger.info(f"Generated requirements file for {db_type}: {output_file}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to generate requirements file: {e}")
            return False


def main():
    parser = argparse.ArgumentParser(
        description='FIMS Lite Configuration Migration Utility',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Create PostgreSQL database configuration
  python config_migration.py create-db-config postgresql
  
  # Migrate object config for MySQL
  python config_migration.py migrate-config object_config.json mysql
  
  # Validate configuration compatibility
  python config_migration.py validate object_config.json database_config.json
  
  # Generate requirements.txt for Oracle
  python config_migration.py generate-requirements oracle
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Create database config command
    create_parser = subparsers.add_parser('create-db-config', help='Create database configuration')
    create_parser.add_argument('db_type', choices=['oracle', 'postgresql', 'informix', 'mysql', 'sqlserver'])
    create_parser.add_argument('-o', '--output', default='database_config.json', help='Output file')
    
    # Migrate object config command
    migrate_parser = subparsers.add_parser('migrate-config', help='Migrate object configuration')
    migrate_parser.add_argument('source', help='Source object configuration file')
    migrate_parser.add_argument('target_db', choices=['oracle', 'postgresql', 'informix', 'mysql', 'sqlserver'])
    migrate_parser.add_argument('-o', '--output', help='Output file (default: object_config_<db_type>.json)')
    
    # Validate compatibility command
    validate_parser = subparsers.add_parser('validate', help='Validate configuration compatibility')
    validate_parser.add_argument('object_config', help='Object configuration file')
    validate_parser.add_argument('database_config', help='Database configuration file')
    
    # Generate requirements command
    req_parser = subparsers.add_parser('generate-requirements', help='Generate requirements.txt')
    req_parser.add_argument('db_type', choices=['oracle', 'postgresql', 'informix', 'mysql', 'sqlserver'])
    req_parser.add_argument('-o', '--output', default='requirements_db.txt', help='Output file')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return 1
    
    migration = ConfigMigration()
    
    if args.command == 'create-db-config':
        success = migration.create_database_config(args.db_type, args.output)
    elif args.command == 'migrate-config':
        success = migration.migrate_object_config(args.source, args.target_db, args.output)
    elif args.command == 'validate':
        success = migration.validate_config_compatibility(args.object_config, args.database_config)
    elif args.command == 'generate-requirements':
        success = migration.generate_requirements_txt(args.db_type, args.output)
    else:
        logger.error(f"Unknown command: {args.command}")
        return 1
    
    return 0 if success else 1


if __name__ == '__main__':
    sys.exit(main())