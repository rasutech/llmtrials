#!/usr/bin/env python3
"""
Simple script to test database connection
"""
from database_abstraction import DatabaseAbstraction
import sys

def test_connection():
    try:
        print("Testing database connection...")
        
        # Initialize database abstraction
        db = DatabaseAbstraction('database_config.json')
        print(f"✓ Database type: {db.db_type}")
        print(f"✓ Host: {db.db_config['host']}:{db.db_config['port']}")
        
        # Get connection string (without credentials for display)
        conn_str = db.get_connection_string()
        safe_conn_str = conn_str.replace(f":{db.db_config['password']}@", ":***@")
        print(f"✓ Connection string: {safe_conn_str}")
        
        # Test actual connection
        import psycopg2
        conn = psycopg2.connect(
            host=db.db_config['host'],
            port=db.db_config['port'],
            user=db.db_config['username'],
            password=db.db_config['password'],
            database=db.db_config.get('database', 'postgres')
        )
        
        # Test simple query
        cursor = conn.cursor()
        cursor.execute("SELECT version();")
        version = cursor.fetchone()
        print(f"✓ PostgreSQL version: {version[0]}")
        
        # Test schema access
        schema = db.db_config.get('default_schema', 'public')
        cursor.execute(f"SELECT schema_name FROM information_schema.schemata WHERE schema_name = '{schema}';")
        schema_exists = cursor.fetchone()
        if schema_exists:
            print(f"✓ Schema '{schema}' exists")
        else:
            print(f"⚠ Schema '{schema}' does not exist")
        
        cursor.close()
        conn.close()
        print("✓ Connection test successful!")
        return True
        
    except ImportError as e:
        print(f"✗ Missing database driver: {e}")
        print("Install with: pip install psycopg2-binary")
        return False
    except Exception as e:
        print(f"✗ Connection failed: {e}")
        return False

if __name__ == "__main__":
    success = test_connection()
    sys.exit(0 if success else 1)