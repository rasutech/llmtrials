from flask import Flask, render_template, request, jsonify, redirect, url_for
from data_models_v2 import DataModel
from db_manager_v2 import get_db_manager, close_db_manager
import json
import logging
import atexit
from datetime import datetime, date

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),  # Console output
    ]
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'

data_model = DataModel()

def get_table_for_field(field_name):
    """Helper function to determine which table to link to based on field name"""
    field_map = {
        'spliceclosureipid': 'spliceclosure',
        'signalipid': 'signal',
        'equipmentipid': 'fiberequipment',
        'ipid': 'signal'  # default for generic ipid
    }
    return field_map.get(field_name.lower(), 'signal')

# Register the function for use in Jinja2 templates
app.jinja_env.globals.update(get_table_for_field=get_table_for_field)

def make_json_safe(obj):
    """Convert database objects to JSON-safe format"""
    try:
        if obj is None:
            return None
        elif isinstance(obj, (str, int, float, bool)):
            return obj
        elif isinstance(obj, (datetime, date)):
            return obj.isoformat()
        elif isinstance(obj, dict):
            return {key: make_json_safe(value) for key, value in obj.items()}
        elif isinstance(obj, list):
            return [make_json_safe(item) for item in obj]
        else:
            # Get the type name for debugging
            type_name = type(obj).__name__
            logger.debug(f"Converting object of type {type_name} to JSON-safe format")
            
            # Try to handle numeric types generically
            if hasattr(obj, '__float__'):
                try:
                    return float(obj)
                except (ValueError, TypeError):
                    pass
            
            # Try to handle as string
            return str(obj)
            
    except Exception as e:
        logger.warning(f"Error making object JSON-safe: {e}, object type: {type(obj)}")
        # Last resort - return string representation
        return str(obj)

def cleanup():
    close_db_manager()

atexit.register(cleanup)

@app.route('/')
def index():
    try:
        with open('object_config.json', 'r') as f:
            config = json.load(f)
            tables = list(config['tables'].keys())
        return render_template('index.html', tables=tables)
    except Exception as e:
        logger.error(f"Error loading index: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/search_master/<table_name>')
def search_master_table(table_name):
    try:
        search_value = request.args.get('search_value')
        if not search_value:
            return redirect(url_for('index'))
        
        table_info = data_model.get_table_info(table_name)
        if not table_info:
            return jsonify({'error': f'Table {table_name} not found'}), 404
        
        results = data_model.search_master_table(table_name, search_value)
        
        # Make results JSON-safe for template serialization
        json_safe_results = []
        for result in results:
            json_safe_record = make_json_safe(result['record'])
            # Pre-serialize the record data to avoid template JSON issues
            import html
            record_json = html.escape(json.dumps(json_safe_record))
            
            json_safe_results.append({
                'table_name': result['table_name'],
                'matched_field': result['matched_field'],
                'matched_value': result['matched_value'],
                'record': json_safe_record,
                'record_json': record_json
            })
        
        return render_template('navigation.html', 
                             master_table=table_name,
                             search_value=search_value,
                             results=json_safe_results,
                             navigation_stack=[])
    except Exception as e:
        logger.error(f"Error searching master table {table_name}: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/navigate/<table_name>/<id_field>/<path:id_value>')
def navigate_relationship(table_name, id_field, id_value):
    try:
        # Get navigation stack from query parameters
        navigation_stack = request.args.getlist('stack')
        
        record = data_model.get_record_by_id(table_name, id_field, id_value)
        if not record:
            return jsonify({'error': 'Record not found'}), 404
        
        # Make record JSON-safe for template serialization
        json_safe_record = make_json_safe(record)
        # Pre-serialize the record data to avoid template JSON issues
        record_json = json.dumps(json_safe_record)
        
        # Add current record to navigation stack
        current_item = {
            'table_name': table_name,
            'record': json_safe_record,
            'record_json': record_json,
            'display_field': id_field,
            'display_value': id_value
        }
        
        return render_template('navigation.html',
                             current_record=current_item,
                             navigation_stack=navigation_stack,
                             table_name=table_name)
    except Exception as e:
        logger.error(f"Error navigating relationship: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/search')
def search():
    try:
        key_field = request.args.get('key_field')
        key_value = request.args.get('key_value')
        
        if not key_field or not key_value:
            return render_template('search.html', results=None, key_field=key_field, key_value=key_value)
        
        # Get results from search method
        search_results = data_model.search_by_key(key_field, key_value)
        
        if not search_results:
            return render_template('search.html', results=[], key_field=key_field, key_value=key_value)
        
        # Process results with the same format as master table search for consistency
        json_safe_results = []
        for result in search_results:
            json_safe_record = make_json_safe(result['record'])
            # Pre-serialize the record data to avoid template JSON issues
            import html
            record_json = html.escape(json.dumps(json_safe_record))
            
            json_safe_results.append({
                'table_name': result['table_name'],
                'matched_field': result['matched_field'],
                'matched_value': result['matched_value'],
                'record': json_safe_record,
                'record_json': record_json
            })
        
        # Use navigation.html template for consistency with master table search
        return render_template('navigation.html', 
                             search_type='general_search',
                             key_field=key_field,
                             key_value=key_value,
                             results=json_safe_results,
                             navigation_stack=[])
    except Exception as e:
        logger.error(f"Error searching: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/trace_signal/<signal_ipid>')
def trace_signal(signal_ipid):
    try:
        trace_results = data_model.trace_signal(signal_ipid)
        
        return render_template('signal_trace.html',
                             signal_ipid=signal_ipid,
                             trace_results=trace_results)
    except Exception as e:
        logger.error(f"Error tracing signal: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/validate/<table_name>/<fqn_id>')
def validate_integrity(table_name, fqn_id):
    try:
        validation_results = data_model.validate_data_integrity(table_name, fqn_id)
        
        return render_template('validation_results.html',
                             table_name=table_name,
                             fqn_id=fqn_id,
                             validation_results=validation_results)
    except Exception as e:
        logger.error(f"Error validating integrity: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/related/<table_name>/<parent_table>/<parent_field>/<path:parent_value>')
def api_get_related_records(table_name, parent_table, parent_field, parent_value):
    try:
        # Try to get records from database first
        try:
            # Find the relationship configuration
            parent_table_info = data_model.get_table_info(parent_table)
            if not parent_table_info:
                return jsonify({'error': f'Parent table {parent_table} not found'}), 404
            
            relationships = parent_table_info.get('relationships', {}).get('children', [])
            target_relationship = None
            
            for rel in relationships:
                if rel['table'].lower() == table_name.lower():
                    target_relationship = rel
                    break
            
            if not target_relationship:
                return jsonify({'error': f'No relationship found from {parent_table} to {table_name}'}), 404
            
            # Build filter based on relationship
            filters = {target_relationship['foreign_key']: parent_value}
            records = data_model.get_records(table_name, filters)
            
            # Make records JSON-safe
            json_safe_records = [make_json_safe(record) for record in records]
            
            return jsonify({
                'parent_table': parent_table,
                'parent_field': parent_field,
                'parent_value': parent_value,
                'child_table': table_name,
                'records': json_safe_records,
                'relationship': target_relationship
            })
            
        except Exception as db_error:
            logger.warning(f"Database error getting related records: {db_error}")
            # Fallback: return empty result set with relationship info
            with open('object_config.json', 'r') as f:
                config = json.load(f)
                parent_table_info = config['tables'].get(parent_table.lower(), {})
                
            if not parent_table_info:
                return jsonify({'error': f'Parent table {parent_table} not found'}), 404
            
            relationships = parent_table_info.get('relationships', {}).get('children', [])
            target_relationship = None
            
            for rel in relationships:
                if rel['table'].lower() == table_name.lower():
                    target_relationship = rel
                    break
            
            if not target_relationship:
                return jsonify({'error': f'No relationship found from {parent_table} to {table_name}'}), 404
            
            return jsonify({
                'parent_table': parent_table,
                'parent_field': parent_field,
                'parent_value': parent_value,
                'child_table': table_name,
                'records': [],  # Empty records due to database error
                'relationship': target_relationship,
                'warning': 'No database connection - showing relationship structure only'
            })
            
    except Exception as e:
        logger.error(f"API error getting related records: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/record/<table_name>/<id_field>/<id_value>')
def api_get_record(table_name, id_field, id_value):
    try:
        record = data_model.get_record_by_id(table_name, id_field, id_value)
        if not record:
            return jsonify({'error': 'Record not found'}), 404
        
        # Make record JSON-safe
        json_safe_record = make_json_safe(record)
        return jsonify(json_safe_record)
    except Exception as e:
        logger.error(f"API error getting record: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/trace_signal/<signal_ipid>')
def api_trace_signal(signal_ipid):
    try:
        trace_results = data_model.trace_signal(signal_ipid)
        # Make trace results JSON-safe
        json_safe_results = make_json_safe(trace_results)
        return jsonify(json_safe_results)
    except Exception as e:
        logger.error(f"API error tracing signal: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/validate/<table_name>/<fqn_id>')
def api_validate_integrity(table_name, fqn_id):
    try:
        validation_results = data_model.validate_data_integrity(table_name, fqn_id)
        return jsonify(validation_results)
    except Exception as e:
        logger.error(f"API error validating integrity: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/table_info/<table_name>')
def api_get_table_info(table_name):
    try:
        logger.debug(f"Getting table info for: {table_name}")
        # Try to get table info directly from config (no database connection needed)
        with open('object_config.json', 'r') as f:
            config = json.load(f)
            table_info = config['tables'].get(table_name.lower(), {})
            
        if not table_info:
            logger.warning(f"Table {table_name} not found in config")
            return jsonify({'error': f'Table {table_name} not found'}), 404
        
        logger.debug(f"Found table info for {table_name}: {len(table_info)} fields")
        return jsonify(table_info)
    except Exception as e:
        logger.error(f"API error getting table info: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/database_info')
def api_get_database_info():
    try:
        db_info = data_model.get_database_info()
        return jsonify(db_info)
    except Exception as e:
        logger.error(f"API error getting database info: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/test_connection')
def api_test_connection():
    try:
        test_result = data_model.test_database_connection()
        return jsonify(test_result)
    except Exception as e:
        logger.error(f"API error testing connection: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/validate_config')
def api_validate_config():
    try:
        validation_result = data_model.validate_configuration()
        return jsonify(validation_result)
    except Exception as e:
        logger.error(f"API error validating config: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/config')
def config_management():
    try:
        db_info = data_model.get_database_info()
        test_result = data_model.test_database_connection()
        validation_result = data_model.validate_configuration()
        
        return render_template('config.html',
                             db_info=db_info,
                             test_result=test_result,
                             validation_result=validation_result)
    except Exception as e:
        logger.error(f"Error loading config page: {e}")
        return jsonify({'error': str(e)}), 500

@app.errorhandler(404)
def not_found(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    return render_template('500.html'), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)