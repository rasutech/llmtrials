import json
from typing import Dict, Any, List, Optional
from db_manager import get_db_manager
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

class DataModel:
    def __init__(self):
        self.db_manager = get_db_manager()
        self.config = self._load_object_config()
    
    def _load_object_config(self) -> Dict[str, Any]:
        try:
            with open('object_config.json', 'r') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Failed to load object configuration: {e}")
            raise
    
    def get_table_info(self, table_name: str) -> Dict[str, Any]:
        return self.config['tables'].get(table_name.lower(), {})
    
    def build_select_query(self, table_name: str, filters: Dict[str, Any] = None, 
                          columns: List[str] = None) -> tuple:
        table_info = self.get_table_info(table_name)
        if not table_info:
            raise ValueError(f"Table {table_name} not found in configuration")
        
        # Get schema prefix
        schema_prefix = table_info.get('schema_prefix', self.config.get('database', {}).get('default_schema_prefix', ''))
        full_table_name = f"{schema_prefix}{table_name}" if schema_prefix else table_name
        
        if columns:
            select_columns = ', '.join(columns)
        else:
            select_columns = '*'
        
        query = f"SELECT {select_columns} FROM {full_table_name}"
        params = {}
        
        if filters:
            where_clauses = []
            for key, value in filters.items():
                if value is not None:
                    param_name = f"p_{key}"
                    where_clauses.append(f"{key} = :{param_name}")
                    params[param_name] = value
                else:
                    where_clauses.append(f"{key} IS NULL")
            
            if where_clauses:
                query += " WHERE " + " AND ".join(where_clauses)
        
        return query, params
    
    def get_record_by_id(self, table_name: str, id_field: str, id_value: Any) -> Optional[Dict[str, Any]]:
        filters = {id_field: id_value}
        query, params = self.build_select_query(table_name, filters)
        results = self.db_manager.execute_query(query, params)
        return results[0] if results else None
    
    def get_records(self, table_name: str, filters: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        query, params = self.build_select_query(table_name, filters)
        return self.db_manager.execute_query(query, params)
    
    def get_related_records(self, table_name: str, record: Dict[str, Any], 
                           relation_type: str = 'children') -> Dict[str, List[Dict[str, Any]]]:
        results = {}
        table_info = self.get_table_info(table_name)
        
        if not table_info:
            return results
        
        relationships = table_info.get('relationships', {}).get(relation_type, [])
        
        for rel in relationships:
            related_table = rel['table']
            
            if relation_type == 'children':
                foreign_key = rel['foreign_key']
                local_key = rel['local_key']
                
                if local_key in record:
                    filters = {foreign_key: record[local_key]}
                    related_data = self.get_records(related_table, filters)
                    if related_data:
                        results[related_table] = related_data
            
            elif relation_type == 'parents':
                foreign_key = rel['foreign_key']
                local_key = rel['local_key']
                
                if foreign_key in record and record[foreign_key]:
                    parent_record = self.get_record_by_id(related_table, local_key, record[foreign_key])
                    if parent_record:
                        if related_table not in results:
                            results[related_table] = []
                        results[related_table].append(parent_record)
        
        return results
    
    def search_by_key(self, key_field: str, key_value: str) -> List[Dict[str, Any]]:
        results = []
        
        for table_name, table_info in self.config['tables'].items():
            fields = table_info.get('fields', {})
            
            if key_field.upper() in fields:
                filters = {key_field.upper(): key_value}
                records = self.get_records(table_name, filters)
                
                for record in records:
                    results.append({
                        'table_name': table_name,
                        'matched_field': key_field.upper(),
                        'matched_value': key_value,
                        'record': record
                    })
        
        return results
    
    def trace_signal(self, signal_ipid: str) -> Dict[str, Any]:
        result = {
            'signal': None,
            'fiber_splices': [],
            'fibers': [],
            'fiber_ports': []
        }
        
        signal_records = self.get_records('signal', {'IPID': signal_ipid})
        if signal_records:
            result['signal'] = signal_records[0]
        
        result['fiber_splices'] = self.get_records('fibersplice', {'SIGNALIPID': signal_ipid})
        result['fibers'] = self.get_records('fiber', {'SIGNALIPID': signal_ipid})
        result['fiber_ports'] = self.get_records('fiberport', {'SIGNALIPID': signal_ipid})
        
        return result
    
    def validate_data_integrity(self, table_name: str, fqn_id: str) -> Dict[str, Any]:
        validation_results = {
            'record': None,
            'issues': [],
            'dependencies': {}
        }
        
        record = self.get_record_by_id(table_name, 'FQN_ID', fqn_id)
        if not record:
            validation_results['issues'].append(f"Record with FQN_ID {fqn_id} not found in {table_name}")
            return validation_results
        
        validation_results['record'] = record
        
        table_info = self.get_table_info(table_name)
        
        for field, field_info in table_info.get('fields', {}).items():
            if not field_info.get('nullable', True) and (field not in record or record[field] is None):
                validation_results['issues'].append(f"Required field {field} is NULL")
        
        children = self.get_related_records(table_name, record, 'children')
        validation_results['dependencies']['children'] = children
        
        for child_table, child_records in children.items():
            validation_results['issues'].append(f"Found {len(child_records)} related records in {child_table}")
        
        if table_name.lower() == 'spliceclosure' and 'IPID' in record and record['IPID']:
            splice_records = self.get_records('fibersplice', {'SPLICECLOSUREIPID': record['IPID']})
            
            for splice in splice_records:
                if splice.get('ASEGMENTIDFKEY'):
                    cable_a = self.get_records('fibercable', {'SEGMENTID': splice['ASEGMENTIDFKEY']})
                    if not cable_a:
                        validation_results['issues'].append(
                            f"FIBERSPLICE {splice['OBJECTID']} references non-existent FIBERCABLE segment {splice['ASEGMENTIDFKEY']}"
                        )
                
                if splice.get('ZSEGMENTIDFKEY'):
                    cable_z = self.get_records('fibercable', {'SEGMENTID': splice['ZSEGMENTIDFKEY']})
                    if not cable_z:
                        validation_results['issues'].append(
                            f"FIBERSPLICE {splice['OBJECTID']} references non-existent FIBERCABLE segment {splice['ZSEGMENTIDFKEY']}"
                        )
                
                if splice.get('SIGNALIPID'):
                    signal = self.get_records('signal', {'IPID': splice['SIGNALIPID']})
                    if not signal:
                        validation_results['issues'].append(
                            f"FIBERSPLICE {splice['OBJECTID']} references non-existent SIGNAL {splice['SIGNALIPID']}"
                        )
        
        return validation_results
    
    def search_master_table(self, table_name: str, search_value: str) -> List[Dict[str, Any]]:
        """Search across multiple key fields in a master table"""
        table_info = self.get_table_info(table_name)
        if not table_info:
            return []
        
        results = []
        unique_keys = table_info.get('unique_keys', [])
        
        for key_field in unique_keys:
            if key_field in table_info.get('fields', {}):
                try:
                    records = self.get_records(table_name, {key_field: search_value})
                    for record in records:
                        # Avoid duplicates
                        if not any(r['record'] == record for r in results):
                            results.append({
                                'table_name': table_name,
                                'matched_field': key_field,
                                'matched_value': search_value,
                                'record': record
                            })
                except Exception as e:
                    logger.warning(f"Error searching {table_name}.{key_field} for '{search_value}': {e}")
                    continue
        
        return results