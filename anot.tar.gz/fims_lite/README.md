# FIMS Lite - Fiber Inventory Management Support Tool

A database-agnostic web application for navigating and validating fiber inventory management systems. Supports Oracle, PostgreSQL, MySQL, SQL Server, and Informix databases through a configurable abstraction layer.

## Features

- **Multi-Database Support**: Oracle, PostgreSQL, MySQL, SQL Server, Informix
- **Relational Navigation**: Progressive navigation through related records without losing context
- **Master Table Search**: Search-driven interface starting from key tables (no full table dumps)
- **Signal Tracing**: Comprehensive signal path tracing across splice, fiber, and port records
- **Data Integrity Validation**: Automated validation of referential integrity and required fields
- **Configuration Management**: Web-based database configuration and migration tools
- **RESTful API**: JSON API endpoints for programmatic access
- **Schema Flexibility**: Configurable schema prefixes and table definitions

## Prerequisites

- Python 3.8+
- Database server (PostgreSQL, Oracle, MySQL, SQL Server, or Informix)
- Network access to your database
- Appropriate database driver (installed automatically)

## Quick Start

### Option 1: Use Existing Database
```bash
# 1. Install core dependencies
pip install -r requirements.txt

# 2. Create database configuration for your database type
python config_migration.py create-db-config postgresql
# OR: oracle, mysql, sqlserver, informix

# 3. Edit database_config.json with your credentials
nano database_config.json

# 4. Test and run
python app.py
```

### Option 2: Set Up PostgreSQL Test Environment
```bash
# Complete automated setup with test data
./test_environment/setup_postgres_test.sh

# Or see detailed instructions:
# test_environment/README_POSTGRES_TEST.md
```

## Installation

1. **Clone the repository:**
```bash
git clone <repository-url>
cd fims_lite
```

2. **Install dependencies:**
```bash
pip install -r requirements.txt
```

3. **Configure database:**
```bash
# Create configuration for your database type
python config_migration.py create-db-config postgresql

# Edit with your database credentials
nano database_config.json
```

4. **Install database driver** (if not already installed):
```bash
# PostgreSQL
pip install psycopg2-binary

# Oracle  
pip install cx_Oracle

# MySQL
pip install pymysql

# SQL Server
pip install pyodbc

# Informix
pip install informixdb
```

## Running the Application

Start the Flask development server:
```bash
python app.py
```

The application will be available at: `http://localhost:5000`

## Database Support

| Database | Status | Driver | Configuration |
|----------|--------|---------|---------------|
| **PostgreSQL** | ✅ Production Ready | psycopg2 | `create-db-config postgresql` |
| **Oracle** | ✅ Production Ready | cx_Oracle | `create-db-config oracle` |
| **MySQL** | ✅ Production Ready | PyMySQL | `create-db-config mysql` |
| **SQL Server** | ⚠️ Beta Support | pyodbc | `create-db-config sqlserver` |
| **Informix** | ⚠️ Beta Support | informixdb | `create-db-config informix` |

## Usage

### Web Interface

1. **Home Page**: Master table search interface (no full table dumps)
2. **Relational Navigation**: Click relationships to load child records progressively
3. **Configuration Management**: `/config` - Test connections and validate configurations
4. **Signal Trace**: Trace signal paths through the network
5. **Data Validation**: Validate data integrity for specific records

### Navigation Flow
```
Search SPLICECLOSURE → Click IPID → Load FIBERSPLICE records →
Click SIGNALIPID → Load SIGNAL records → Continue navigation
```

### API Endpoints

- `GET /api/records/<table_name>` - Get all records from a table
- `GET /api/record/<table_name>/<id_field>/<id_value>` - Get specific record
- `GET /api/trace_signal/<signal_ipid>` - Trace signal connections
- `GET /api/validate/<table_name>/<fqn_id>` - Validate data integrity

### Key Features

#### Hyperlink Navigation
- Click on any IPID, SIGNALIPID, SEGMENTID, etc. to navigate to related records
- Automatic detection of relationship fields

#### Data Integrity Validation
- Checks for NULL values in required fields
- Verifies foreign key relationships exist
- Reports orphaned records and broken references
- Counts dependent records

#### Signal Tracing
- Shows all fiber splices, fibers, and ports for a signal
- Displays complete signal path information
- Links to all related equipment and cable records

## Test Environment

### 🧪 PostgreSQL Test Setup (Development)
```bash
# Automated test environment with realistic data
./test_environment/setup_postgres_test.sh

# Generates ~8,400 realistic fiber network records
# Includes: splice closures, equipment, cables, signals, fibers, ports, splices
```

For detailed test setup instructions, see:
- [`test_environment/README_POSTGRES_TEST.md`](test_environment/README_POSTGRES_TEST.md) - PostgreSQL test guide
- [`test_environment/README_DATABASE_SETUP.md`](test_environment/README_DATABASE_SETUP.md) - Multi-database guide

**⚠️ Important**: The `test_environment/` directory contains development/testing tools only and should be **excluded from production deployments**. See [`DEPLOYMENT.md`](DEPLOYMENT.md) for deployment instructions.

## Configuration

### Database Configuration
```bash
# Create configuration for your database
python config_migration.py create-db-config postgresql

# Migrate object configuration for different databases
python config_migration.py migrate-config object_config.json mysql

# Validate compatibility
python config_migration.py validate object_config.json database_config.json
```

### Adding New Tables
Edit `object_config.json` to add new table definitions:
```json
{
  "tables": {
    "NEW_TABLE": {
      "table_name": "NEW_TABLE",
      "description": "Description",
      "primary_keys": ["OBJECTID"],
      "unique_keys": ["IPID", "FQN_ID"],
      "fields": {
        "OBJECTID": {"type": "NUMBER", "nullable": false},
        "IPID": {"type": "NVARCHAR2", "nullable": true, "size": 90}
      },
      "relationships": {
        "children": [...],
        "parents": [...]
      }
    }
  }
}
```

### Multi-Database Migration
```bash
# Switch from Oracle to PostgreSQL
python config_migration.py create-db-config postgresql
python config_migration.py migrate-config object_config.json postgresql
```

## Troubleshooting

### Connection Issues
- The application automatically reconnects on stale connections
- Check Oracle client installation if thick mode errors occur
- Verify network access to database server

### Performance
- Adjust connection pool size based on usage
- Use filters to limit result sets
- API endpoints support pagination parameters

## Architecture

- **Database Abstraction**: Multi-database support through pluggable dialects
- **Flask**: Web framework with RESTful API
- **Configuration-Driven**: No hardcoded SQL, all queries built from JSON configuration
- **Progressive Navigation**: Hierarchical data loading preserving context
- **Connection Management**: Database-specific connection pooling and management

### File Structure
```
fims_lite/
├── app.py                      # Main Flask application  
├── data_models_v2.py          # Database-agnostic data access layer
├── database_abstraction.py    # Multi-database dialect support
├── db_manager_v2.py          # Connection management
├── config_migration.py       # Configuration utilities
├── object_config.json        # Business object definitions
├── database_config.json      # Database connection settings
├── templates/                # Web interface templates
├── static/                   # CSS and static assets
├── test_environment/         # Development/testing tools (EXCLUDE from production)
└── DEPLOYMENT.md            # Production deployment guide
```

## Deployment

For production deployment instructions, see [`DEPLOYMENT.md`](DEPLOYMENT.md).

**Key Points:**
- ✅ **Include**: Core application files, templates, static assets
- ❌ **Exclude**: `test_environment/` directory and generated test files
- 🔧 **Configure**: Database credentials and connection settings

## Security Notes

- **Database Credentials**: Use environment variables or secure configuration management
- **Network Security**: Restrict database access to application servers only  
- **HTTPS**: Use reverse proxy (nginx/Apache) for SSL termination
- **Database Permissions**: Use dedicated application user with minimal required privileges
- **Configuration Validation**: Use `/config` endpoint to validate setup

## Development

### Extending the Application
1. **Add Tables**: Update `object_config.json` with new table definitions
2. **Database Support**: Add new dialects to `database_abstraction.py`
3. **Custom Logic**: Extend `data_models_v2.py` for business rules
4. **Web Interface**: Add routes in `app.py` and templates in `templates/`
5. **Testing**: Use test environment tools in `test_environment/`

### Contributing
- **Test Changes**: Use PostgreSQL test environment for development
- **Multiple Databases**: Test configuration migration across database types  
- **Documentation**: Update relevant README files
- **Deployment**: Verify production deployment excludes test files

## License

For internal use only.