# FIMS Lite Deployment Guide

This guide explains how to deploy FIMS Lite to production, including what files to ship and what to exclude.

## 📦 Production Package Contents

### ✅ Files to Include (Ship)

#### Core Application Files
```
app.py                      # Main Flask application
data_models_v2.py          # Data access layer
database_abstraction.py    # Database abstraction layer
db_manager_v2.py          # Database connection management
config_migration.py       # Configuration migration utility
object_config.json        # Business object definitions
requirements.txt          # Core Python dependencies
```

#### Web Interface
```
templates/                 # HTML templates
├── base.html             # Base template
├── index.html            # Home page
├── navigation.html       # Relational navigation
├── config.html           # Configuration management
├── search.html           # Search interface
├── signal_trace.html     # Signal tracing
├── validation_results.html # Data validation
├── 404.html              # Error pages
└── 500.html

static/                    # Static web assets
└── css/
    └── style.css         # Application styles
```

#### Configuration Files
```
database_config.json       # Database connection settings (customize)
.gitignore                # Git exclusions (optional)
```

### ❌ Files to Exclude (Don't Ship)

#### Test Environment (Entire Directory)
```
test_environment/          # Complete test environment
├── test_data_generator.py # Test data generation
├── sql_generator.py       # SQL script generation
├── db_loader.py          # Database loading utilities
├── setup_postgres_test.sh # Automated test setup
├── requirements_postgres.txt # Test-only dependencies
├── README_POSTGRES_TEST.md # Test documentation
├── README_DATABASE_SETUP.md # Multi-DB documentation
└── README.md             # Test environment guide
```

#### Legacy Files (if present)
```
data_models.py             # Original data models (use data_models_v2.py)
db_manager.py              # Original DB manager (use db_manager_v2.py)
db_config.json            # Old config format
```

#### Generated Test Files
```
test_data*.json           # Generated test data
create_fims_schema*.sql   # Generated SQL scripts
load_test_data*.sql       # Generated data loading scripts
sample_queries.sql        # Generated sample queries
object_config_*.json      # Migrated configurations (except main one)
*.backup                  # Backup files
```

#### Development Files
```
__pycache__/              # Python cache
*.pyc, *.pyo, *.pyd      # Compiled Python
.pytest_cache/           # Test cache
*.log                    # Log files
.vscode/, .idea/         # IDE settings
*.swp, *.swo, *~        # Editor temp files
.DS_Store               # macOS files
```

## 🚀 Deployment Methods

### Method 1: Git Deployment (Recommended)
```bash
# Clone repository (production branch)
git clone --depth 1 --branch production https://github.com/your-org/fims-lite.git

# Install only production dependencies
cd fims-lite
pip install -r requirements.txt

# Configure database
cp database_config.json.example database_config.json
# Edit database_config.json with production settings
```

### Method 2: Archive Deployment
```bash
# Create production archive (excludes test_environment)
tar --exclude='test_environment' \
    --exclude='*.pyc' \
    --exclude='__pycache__' \
    --exclude='.git' \
    -czf fims_lite_production.tar.gz .

# Extract on production server
tar -xzf fims_lite_production.tar.gz -C /opt/fims_lite/
```

### Method 3: Docker Deployment
```dockerfile
# Dockerfile
FROM python:3.9-slim

WORKDIR /app

# Copy only production files
COPY requirements.txt .
COPY app.py .
COPY data_models_v2.py .
COPY database_abstraction.py .
COPY db_manager_v2.py .
COPY config_migration.py .
COPY object_config.json .
COPY templates/ templates/
COPY static/ static/

# Install production dependencies only
RUN pip install --no-cache-dir -r requirements.txt

# Create non-root user
RUN useradd -m -u 1000 fims && chown -R fims:fims /app
USER fims

EXPOSE 5000
CMD ["python", "app.py"]
```

### Method 4: rsync Deployment
```bash
# Sync to production server (excluding test files)
rsync -av \
  --exclude='test_environment/' \
  --exclude='__pycache__/' \
  --exclude='*.pyc' \
  --exclude='.git/' \
  --exclude='test_data*.json' \
  --exclude='*.sql' \
  . production_server:/opt/fims_lite/
```

## ⚙️ Production Configuration

### 1. Database Configuration
```bash
# Create production database config
python config_migration.py create-db-config postgresql
# OR
python config_migration.py create-db-config oracle

# Edit database_config.json with production credentials
nano database_config.json
```

### 2. Environment Variables (Recommended)
```bash
# Set production environment variables
export FIMS_DB_HOST=prod-db.company.com
export FIMS_DB_USER=fims_prod
export FIMS_DB_PASSWORD=secure_password
export FIMS_DB_NAME=fims_production
export FLASK_ENV=production
```

### 3. Application Configuration
```bash
# Test database connection
python -c "from data_models_v2 import DataModel; dm = DataModel(); print(dm.test_database_connection())"

# Validate configuration
curl http://localhost:5000/api/test_connection
curl http://localhost:5000/api/validate_config
```

## 🔒 Security Checklist

- [ ] **Remove test credentials**: No default/test passwords in config files
- [ ] **Exclude test environment**: Entire `test_environment/` directory excluded
- [ ] **Secure database access**: Use dedicated production database user with minimal privileges
- [ ] **HTTPS only**: Configure reverse proxy (nginx/Apache) for HTTPS termination
- [ ] **Network isolation**: Database access restricted to application servers only
- [ ] **Log management**: Configure proper logging and log rotation
- [ ] **Backup strategy**: Implement database backup and recovery procedures

## 📊 Production Requirements

### Minimum System Requirements
- **Python**: 3.8+
- **RAM**: 512MB minimum, 2GB recommended
- **Storage**: 100MB for application, additional for database
- **Database**: PostgreSQL 9.6+, Oracle 11g+, MySQL 5.7+, SQL Server 2016+

### Python Dependencies (Production Only)
```txt
flask>=2.0.0              # Web framework
python-dateutil>=2.8.0    # Date utilities
[database-driver]          # psycopg2, cx_Oracle, pymysql, etc.
```

### Recommended Production Stack
```
[Load Balancer] → [Reverse Proxy] → [FIMS Lite] → [Database]
    (HAProxy)        (nginx/Apache)    (Python/Flask)   (PostgreSQL/Oracle)
```

## 🔄 Database Migration

### For New Deployments
1. Create production database
2. Use your organization's schema creation process
3. Configure FIMS Lite object_config.json for your schema
4. Test with configuration validation: `/config` endpoint

### For Existing Deployments
1. Review object_config.json changes
2. Apply any necessary schema updates
3. Validate configuration compatibility
4. Test application functionality

## 📈 Monitoring and Maintenance

### Health Checks
```bash
# Application health
curl http://localhost:5000/

# Database connectivity
curl http://localhost:5000/api/test_connection

# Configuration validation
curl http://localhost:5000/api/validate_config
```

### Log Locations
```
/var/log/fims_lite/app.log        # Application logs
/var/log/nginx/fims_lite.log      # Web server logs (if using nginx)
[database-logs]                   # Database-specific log locations
```

### Performance Optimization
- **Database**: Ensure proper indexes on key lookup fields (IPID, FQN_ID, etc.)
- **Application**: Consider connection pooling for high-concurrency environments
- **Web Server**: Use reverse proxy with gzip compression and static file caching

## 🆘 Troubleshooting

### Common Issues
1. **Import errors**: Ensure you're using `data_models_v2.py`, not `data_models.py`
2. **Database connection**: Check `database_config.json` credentials and network access
3. **Missing templates**: Ensure complete `templates/` and `static/` directories copied
4. **Configuration errors**: Use `/config` endpoint to validate setup

### Support
- **Configuration**: Use built-in configuration management at `/config`
- **Database issues**: Check database-specific documentation in excluded test guides
- **Application errors**: Review Flask application logs

---

## 📋 Deployment Checklist

**Pre-Deployment:**
- [ ] Create production database and user
- [ ] Configure `database_config.json` with production credentials  
- [ ] Test database connection from application server
- [ ] Review and customize `object_config.json` for your schema

**Deployment:**
- [ ] Copy production files only (exclude `test_environment/`)
- [ ] Install production dependencies: `pip install -r requirements.txt`
- [ ] Set appropriate file permissions and ownership
- [ ] Configure reverse proxy and HTTPS

**Post-Deployment:**
- [ ] Verify application starts: `python app.py`
- [ ] Test web interface: `http://your-server:5000`
- [ ] Validate configuration: `http://your-server:5000/config`
- [ ] Test key functionality: search, navigation, validation
- [ ] Configure monitoring and log rotation
- [ ] Document deployment specifics for your organization

**Security:**
- [ ] Change default credentials and secrets
- [ ] Restrict database access to application servers only
- [ ] Enable HTTPS and disable HTTP
- [ ] Configure appropriate firewall rules
- [ ] Set up log monitoring and alerting

This deployment excludes all test-related files while maintaining the complete production functionality of FIMS Lite! 🚀