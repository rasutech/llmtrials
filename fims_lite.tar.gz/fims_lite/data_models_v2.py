import json
from typing import Dict, Any, List, Optional
from db_manager_v2 import get_db_manager
from database_abstraction import DatabaseAbstraction
import logging

logger = logging.getLogger(__name__)

class DataModel:
    def __init__(self, object_config_file: str = 'object_config.json', 
                 database_config_file: str = 'database_config.json'):
        self.db_manager = get_db_manager(database_config_file)
        self.db_abstraction = DatabaseAbstraction(database_config_file)
        self.config = self._load_object_config(object_config_file)
    
    def _load_object_config(self, config_file: str) -> Dict[str, Any]:
        try:
            with open(config_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Failed to load object configuration: {e}")
            raise
    
    def get_table_info(self, table_name: str) -> Dict[str, Any]:
        return self.config['tables'].get(table_name.upper(), {})
    
    def build_select_query(self, table_name: str, filters: Dict[str, Any] = None, 
                          columns: List[str] = None, limit: int = None, 
                          offset: int = 0) -> tuple:
        """Build SELECT query using database abstraction layer"""
        table_info = self.get_table_info(table_name)
        if not table_info:
            raise ValueError(f"Table {table_name} not found in configuration")
        
        # Use database abstraction to build the query
        query, params = self.db_abstraction.build_select_query(
            table_name=table_name,
            schema=None,  # Will use default schema from database config
            columns=columns,
            filters=filters,
            limit=limit,
            offset=offset
        )
        
        return query, params
    
    def get_record_by_id(self, table_name: str, id_field: str, id_value: Any) -> Optional[Dict[str, Any]]:
        filters = {id_field: id_value}
        query, params = self.build_select_query(table_name, filters)
        results = self.db_manager.execute_query(query, params)
        return results[0] if results else None
    
    def get_records(self, table_name: str, filters: Dict[str, Any] = None, 
                   limit: int = None, offset: int = 0) -> List[Dict[str, Any]]:
        query, params = self.build_select_query(table_name, filters, limit=limit, offset=offset)
        return self.db_manager.execute_query(query, params)
    
    def get_related_records(self, table_name: str, record: Dict[str, Any], 
                           relation_type: str = 'children') -> Dict[str, List[Dict[str, Any]]]:
        results = {}
        table_info = self.get_table_info(table_name)
        
        if not table_info:
            return results
        
        relationships = table_info.get('relationships', {}).get(relation_type, [])
        
        for rel in relationships:
            related_table = rel['table']
            
            try:
                if relation_type == 'children':
                    foreign_key = rel['foreign_key']
                    local_key = rel['local_key']
                    
                    if local_key in record and record[local_key]:
                        filters = {foreign_key: record[local_key]}
                        related_data = self.get_records(related_table, filters)
                        if related_data:
                            results[related_table] = related_data
                
                elif relation_type == 'parents':
                    foreign_key = rel['foreign_key']
                    local_key = rel['local_key']
                    
                    if foreign_key in record and record[foreign_key]:
                        parent_record = self.get_record_by_id(related_table, local_key, record[foreign_key])
                        if parent_record:
                            if related_table not in results:
                                results[related_table] = []
                            results[related_table].append(parent_record)
            
            except Exception as e:
                logger.warning(f"Error getting related records from {related_table}: {e}")
                continue
        
        return results
    
    def search_by_key(self, key_field: str, key_value: str) -> List[Dict[str, Any]]:
        results = []
        
        for table_name, table_info in self.config['tables'].items():
            fields = table_info.get('fields', {})
            
            if key_field.upper() in fields:
                try:
                    filters = {key_field.upper(): key_value}
                    records = self.get_records(table_name, filters)
                    
                    for record in records:
                        results.append({
                            'table_name': table_name,
                            'matched_field': key_field.upper(),
                            'matched_value': key_value,
                            'record': record
                        })
                except Exception as e:
                    logger.warning(f"Error searching {table_name}.{key_field}: {e}")
                    continue
        
        return results
    
    def search_master_table(self, table_name: str, search_value: str) -> List[Dict[str, Any]]:
        """Search across multiple key fields in a master table"""
        table_info = self.get_table_info(table_name)
        if not table_info:
            return []
        
        results = []
        unique_keys = table_info.get('unique_keys', [])
        
        for key_field in unique_keys:
            if key_field in table_info.get('fields', {}):
                try:
                    records = self.get_records(table_name, {key_field: search_value})
                    for record in records:
                        # Avoid duplicates
                        if not any(r['record'] == record for r in results):
                            results.append({
                                'table_name': table_name,
                                'matched_field': key_field,
                                'matched_value': search_value,
                                'record': record
                            })
                except Exception as e:
                    logger.warning(f"Error searching {table_name}.{key_field} for '{search_value}': {e}")
                    continue
        
        return results
    
    def trace_signal(self, signal_ipid: str) -> Dict[str, Any]:
        result = {
            'signal': None,
            'fiber_splices': [],
            'fibers': [],
            'fiber_ports': []
        }
        
        try:
            signal_records = self.get_records('SIGNAL', {'IPID': signal_ipid})
            if signal_records:
                result['signal'] = signal_records[0]
            
            result['fiber_splices'] = self.get_records('FIBERSPLICE', {'SIGNALIPID': signal_ipid})
            result['fibers'] = self.get_records('FIBER', {'SIGNALIPID': signal_ipid})
            result['fiber_ports'] = self.get_records('FIBERPORT', {'SIGNALIPID': signal_ipid})
        
        except Exception as e:
            logger.error(f"Error tracing signal {signal_ipid}: {e}")
        
        return result
    
    def validate_data_integrity(self, table_name: str, fqn_id: str) -> Dict[str, Any]:
        validation_results = {
            'record': None,
            'issues': [],
            'dependencies': {}
        }
        
        try:
            record = self.get_record_by_id(table_name, 'FQN_ID', fqn_id)
            if not record:
                validation_results['issues'].append(f"Record with FQN_ID {fqn_id} not found in {table_name}")
                return validation_results
            
            validation_results['record'] = record
            
            table_info = self.get_table_info(table_name)
            
            # Check required fields
            for field, field_info in table_info.get('fields', {}).items():
                if not field_info.get('nullable', True) and (field not in record or record[field] is None):
                    validation_results['issues'].append(f"Required field {field} is NULL")
            
            # Check relationships
            children = self.get_related_records(table_name, record, 'children')
            validation_results['dependencies']['children'] = children
            
            for child_table, child_records in children.items():
                validation_results['issues'].append(f"Found {len(child_records)} related records in {child_table}")
            
            # Specific validation for SPLICECLOSURE
            if table_name.upper() == 'SPLICECLOSURE' and 'IPID' in record and record['IPID']:
                splice_records = self.get_records('FIBERSPLICE', {'SPLICECLOSUREIPID': record['IPID']})
                
                for splice in splice_records:
                    # Validate A segment
                    if splice.get('ASEGMENTIDFKEY'):
                        cable_a = self.get_records('FIBERCABLE', {'SEGMENTID': splice['ASEGMENTIDFKEY']})
                        if not cable_a:
                            validation_results['issues'].append(
                                f"FIBERSPLICE {splice['OBJECTID']} references non-existent FIBERCABLE segment {splice['ASEGMENTIDFKEY']}"
                            )
                    
                    # Validate Z segment
                    if splice.get('ZSEGMENTIDFKEY'):
                        cable_z = self.get_records('FIBERCABLE', {'SEGMENTID': splice['ZSEGMENTIDFKEY']})
                        if not cable_z:
                            validation_results['issues'].append(
                                f"FIBERSPLICE {splice['OBJECTID']} references non-existent FIBERCABLE segment {splice['ZSEGMENTIDFKEY']}"
                            )
                    
                    # Validate signal
                    if splice.get('SIGNALIPID'):
                        signal = self.get_records('SIGNAL', {'IPID': splice['SIGNALIPID']})
                        if not signal:
                            validation_results['issues'].append(
                                f"FIBERSPLICE {splice['OBJECTID']} references non-existent SIGNAL {splice['SIGNALIPID']}"
                            )
        
        except Exception as e:
            logger.error(f"Error validating data integrity: {e}")
            validation_results['issues'].append(f"Validation error: {str(e)}")
        
        return validation_results
    
    def get_database_info(self) -> Dict[str, Any]:
        """Get current database configuration info"""
        return self.db_abstraction.get_database_info()
    
    def test_database_connection(self) -> Dict[str, Any]:
        """Test database connection"""
        return self.db_manager.test_connection()
    
    def get_table_schema(self, table_name: str) -> List[Dict[str, Any]]:
        """Get table schema from database"""
        return self.db_manager.get_table_schema(table_name)
    
    def validate_configuration(self) -> Dict[str, Any]:
        """Validate object configuration against database schema"""
        validation_result = {
            'valid': True,
            'errors': [],
            'warnings': [],
            'tables_validated': 0,
            'fields_validated': 0
        }
        
        try:
            # Test database connection first
            db_test = self.test_database_connection()
            if not db_test['success']:
                validation_result['valid'] = False
                validation_result['errors'].append(f"Database connection failed: {db_test.get('error', 'Unknown error')}")
                return validation_result
            
            # Validate each table configuration
            for table_name, table_config in self.config['tables'].items():
                try:
                    # Get actual schema from database
                    schema_info = self.get_table_schema(table_name)
                    
                    if not schema_info:
                        validation_result['warnings'].append(f"Table {table_name} not found in database or no schema access")
                        continue
                    
                    # Create lookup for database columns
                    db_columns = {col['COLUMN_NAME'].upper(): col for col in schema_info}
                    
                    # Validate configured fields
                    config_fields = table_config.get('fields', {})
                    for field_name, field_config in config_fields.items():
                        field_name_upper = field_name.upper()
                        
                        if field_name_upper not in db_columns:
                            validation_result['warnings'].append(
                                f"Table {table_name}: Configured field {field_name} not found in database"
                            )
                        else:
                            validation_result['fields_validated'] += 1
                    
                    # Check for database fields not in configuration
                    for db_field_name in db_columns:
                        if db_field_name not in config_fields:
                            validation_result['warnings'].append(
                                f"Table {table_name}: Database field {db_field_name} not in configuration"
                            )
                    
                    validation_result['tables_validated'] += 1
                    
                except Exception as e:
                    validation_result['warnings'].append(f"Error validating table {table_name}: {e}")
                    continue
        
        except Exception as e:
            validation_result['valid'] = False
            validation_result['errors'].append(f"Configuration validation failed: {e}")
        
        return validation_result