import logging
import importlib
from typing import Dict, List, Any, Optional
from contextlib import contextmanager
from database_abstraction import DatabaseAbstraction

logger = logging.getLogger(__name__)

class DatabaseManager:
    """Database manager using the abstraction layer"""
    
    def __init__(self, config_file: str = 'database_config.json'):
        self.db_abstraction = DatabaseAbstraction(config_file)
        self.connection = None
        self.cursor = None
        
        # Validate configuration
        validation = self.db_abstraction.validate_connection_config()
        if not validation['valid']:
            logger.error(f"Database configuration errors: {validation['errors']}")
            raise ValueError(f"Invalid database configuration: {'; '.join(validation['errors'])}")
        
        if validation['warnings']:
            for warning in validation['warnings']:
                logger.warning(warning)
        
        # Log database info
        db_info = self.db_abstraction.get_database_info()
        logger.info(f"Initialized database manager: {db_info}")
    
    def connect(self):
        """Establish database connection"""
        if self.connection:
            logger.warning("Connection already exists")
            return
        
        try:
            db_type = self.db_abstraction.db_type
            driver_module = self.db_abstraction.get_driver_module()
            
            if db_type == 'oracle':
                self._connect_oracle()
            elif db_type == 'postgresql':
                self._connect_postgresql()
            elif db_type == 'informix':
                self._connect_informix()
            elif db_type == 'mysql':
                self._connect_mysql()
            elif db_type == 'sqlserver':
                self._connect_sqlserver()
            else:
                raise ValueError(f"Unsupported database type: {db_type}")
            
            logger.info(f"Successfully connected to {db_type} database")
            
        except Exception as e:
            logger.error(f"Failed to connect to database: {e}")
            raise
    
    def _connect_oracle(self):
        """Connect to Oracle database"""
        try:
            cx_Oracle = importlib.import_module('cx_Oracle')
            db_config = self.db_abstraction.db_config
            
            dsn = cx_Oracle.makedsn(
                host=db_config['host'],
                port=db_config['port'],
                service_name=db_config['service_name']
            )
            
            self.connection = cx_Oracle.connect(
                user=db_config['username'],
                password=db_config['password'],
                dsn=dsn,
                **db_config.get('connection_params', {})
            )
            
        except ImportError:
            logger.error("cx_Oracle module not found. Install with: pip install cx_Oracle")
            raise
    
    def _connect_postgresql(self):
        """Connect to PostgreSQL database"""
        try:
            psycopg2 = importlib.import_module('psycopg2')
            db_config = self.db_abstraction.db_config
            
            self.connection = psycopg2.connect(
                host=db_config['host'],
                port=db_config['port'],
                database=db_config['database'],
                user=db_config['username'],
                password=db_config['password'],
                **db_config.get('connection_params', {})
            )
            
        except ImportError:
            logger.error("psycopg2 module not found. Install with: pip install psycopg2-binary")
            raise
    
    def _connect_informix(self):
        """Connect to Informix database"""
        try:
            informixdb = importlib.import_module('informixdb')
            db_config = self.db_abstraction.db_config
            
            conn_string = f"{db_config['database']}@{db_config['host']}:{db_config['port']}"
            
            self.connection = informixdb.connect(
                conn_string,
                user=db_config['username'],
                password=db_config['password'],
                **db_config.get('connection_params', {})
            )
            
        except ImportError:
            logger.error("informixdb module not found. Install with: pip install informixdb")
            raise
    
    def _connect_mysql(self):
        """Connect to MySQL database"""
        try:
            pymysql = importlib.import_module('pymysql')
            db_config = self.db_abstraction.db_config
            
            self.connection = pymysql.connect(
                host=db_config['host'],
                port=db_config['port'],
                database=db_config['database'],
                user=db_config['username'],
                password=db_config['password'],
                **db_config.get('connection_params', {})
            )
            
        except ImportError:
            logger.error("pymysql module not found. Install with: pip install pymysql")
            raise
    
    def _connect_sqlserver(self):
        """Connect to SQL Server database"""
        try:
            pyodbc = importlib.import_module('pyodbc')
            db_config = self.db_abstraction.db_config
            
            conn_string = (
                f"DRIVER={{ODBC Driver 17 for SQL Server}};"
                f"SERVER={db_config['host']},{db_config['port']};"
                f"DATABASE={db_config['database']};"
                f"UID={db_config['username']};"
                f"PWD={db_config['password']}"
            )
            
            self.connection = pyodbc.connect(
                conn_string,
                **db_config.get('connection_params', {})
            )
            
        except ImportError:
            logger.error("pyodbc module not found. Install with: pip install pyodbc")
            raise
    
    def disconnect(self):
        """Close database connection"""
        try:
            if self.cursor:
                self.cursor.close()
                self.cursor = None
            
            if self.connection:
                self.connection.close()
                self.connection = None
                
            logger.info("Database connection closed")
            
        except Exception as e:
            logger.error(f"Error closing database connection: {e}")
    
    @contextmanager
    def get_cursor(self):
        """Context manager for database cursor"""
        if not self.connection:
            self.connect()
        
        cursor = None
        try:
            cursor = self.connection.cursor()
            yield cursor
            self.connection.commit()
        except Exception as e:
            if self.connection:
                self.connection.rollback()
            logger.error(f"Database operation failed: {e}")
            raise
        finally:
            if cursor:
                cursor.close()
    
    def execute_query(self, query: str, params: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        """Execute a SELECT query and return results as list of dictionaries"""
        if params is None:
            params = {}
        
        try:
            with self.get_cursor() as cursor:
                logger.debug(f"Executing query: {query}")
                logger.debug(f"With parameters: {params}")
                
                # Handle different parameter styles
                if self.db_abstraction.dialect.parameter_style == 'qmark':
                    # Convert named parameters to positional
                    param_values = list(params.values())
                    cursor.execute(query, param_values)
                else:
                    cursor.execute(query, params)
                
                # Get column names
                if hasattr(cursor, 'description') and cursor.description:
                    columns = [desc[0].upper() for desc in cursor.description]
                    
                    # Fetch all results
                    rows = cursor.fetchall()
                    
                    # Convert to list of dictionaries
                    results = []
                    for row in rows:
                        row_dict = {}
                        for i, value in enumerate(row):
                            row_dict[columns[i]] = value
                        results.append(row_dict)
                    
                    logger.debug(f"Query returned {len(results)} rows")
                    return results
                else:
                    return []
                
        except Exception as e:
            logger.error(f"Query execution failed: {e}")
            logger.error(f"Query: {query}")
            logger.error(f"Parameters: {params}")
            raise
    
    def execute_non_query(self, query: str, params: Dict[str, Any] = None) -> int:
        """Execute INSERT, UPDATE, or DELETE query and return affected row count"""
        if params is None:
            params = {}
        
        try:
            with self.get_cursor() as cursor:
                logger.debug(f"Executing non-query: {query}")
                logger.debug(f"With parameters: {params}")
                
                if self.db_abstraction.dialect.parameter_style == 'qmark':
                    param_values = list(params.values())
                    cursor.execute(query, param_values)
                else:
                    cursor.execute(query, params)
                
                affected_rows = cursor.rowcount
                logger.debug(f"Non-query affected {affected_rows} rows")
                return affected_rows
                
        except Exception as e:
            logger.error(f"Non-query execution failed: {e}")
            logger.error(f"Query: {query}")
            logger.error(f"Parameters: {params}")
            raise
    
    def test_connection(self) -> Dict[str, Any]:
        """Test database connection and return connection info"""
        try:
            if not self.connection:
                self.connect()
            
            # Test with a simple query
            test_query = "SELECT 1 as test_value"
            if self.db_abstraction.db_type == 'oracle':
                test_query = "SELECT 1 as test_value FROM DUAL"
            
            result = self.execute_query(test_query)
            
            return {
                'success': True,
                'database_type': self.db_abstraction.db_type,
                'driver': self.db_abstraction.get_driver_module(),
                'default_schema': self.db_abstraction.get_default_schema(),
                'test_result': result[0] if result else None
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'database_type': self.db_abstraction.db_type
            }
    
    def get_table_schema(self, table_name: str, schema: str = None) -> List[Dict[str, Any]]:
        """Get table schema information"""
        if schema is None:
            schema = self.db_abstraction.get_default_schema()
        
        try:
            db_type = self.db_abstraction.db_type
            
            if db_type == 'oracle':
                query = """
                    SELECT COLUMN_NAME, DATA_TYPE, DATA_LENGTH, DATA_PRECISION, 
                           DATA_SCALE, NULLABLE, DATA_DEFAULT
                    FROM ALL_TAB_COLUMNS 
                    WHERE OWNER = :schema AND TABLE_NAME = :table_name
                    ORDER BY COLUMN_ID
                """
                params = {'schema': schema.upper(), 'table_name': table_name.upper()}
                
            elif db_type == 'postgresql':
                query = """
                    SELECT column_name, data_type, character_maximum_length,
                           numeric_precision, numeric_scale, is_nullable, column_default
                    FROM information_schema.columns
                    WHERE table_schema = %(schema)s AND table_name = %(table_name)s
                    ORDER BY ordinal_position
                """
                params = {'schema': schema.lower(), 'table_name': table_name.lower()}
                
            elif db_type == 'mysql':
                query = """
                    SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH,
                           NUMERIC_PRECISION, NUMERIC_SCALE, IS_NULLABLE, COLUMN_DEFAULT
                    FROM information_schema.columns
                    WHERE table_schema = %(schema)s AND table_name = %(table_name)s
                    ORDER BY ordinal_position
                """
                params = {'schema': schema, 'table_name': table_name}
                
            else:
                logger.warning(f"Schema introspection not implemented for {db_type}")
                return []
            
            return self.execute_query(query, params)
            
        except Exception as e:
            logger.error(f"Failed to get table schema: {e}")
            return []


# Global database manager instance
_db_manager = None

def get_db_manager(config_file: str = 'database_config.json') -> DatabaseManager:
    """Get singleton database manager instance"""
    global _db_manager
    if _db_manager is None:
        _db_manager = DatabaseManager(config_file)
    return _db_manager

def close_db_manager():
    """Close database manager connection"""
    global _db_manager
    if _db_manager:
        _db_manager.disconnect()
        _db_manager = None