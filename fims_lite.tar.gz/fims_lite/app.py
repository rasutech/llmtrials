from flask import Flask, render_template, request, jsonify, redirect, url_for
from data_models import DataModel
from db_manager import get_db_manager, close_db_manager
import json
import logging
import atexit

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'

data_model = DataModel()

def cleanup():
    close_db_manager()

atexit.register(cleanup)

@app.route('/')
def index():
    try:
        with open('object_config.json', 'r') as f:
            config = json.load(f)
            tables = list(config['tables'].keys())
        return render_template('index.html', tables=tables)
    except Exception as e:
        logger.error(f"Error loading index: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/table/<table_name>')
def view_table(table_name):
    try:
        table_info = data_model.get_table_info(table_name)
        if not table_info:
            return jsonify({'error': f'Table {table_name} not found'}), 404
        
        filters = {}
        for field in table_info.get('fields', {}).keys():
            value = request.args.get(field)
            if value:
                filters[field] = value
        
        records = data_model.get_records(table_name, filters if filters else None)
        
        return render_template('table_view.html', 
                             table_name=table_name,
                             table_info=table_info,
                             records=records,
                             filters=filters)
    except Exception as e:
        logger.error(f"Error viewing table {table_name}: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/record/<table_name>/<id_field>/<id_value>')
def view_record(table_name, id_field, id_value):
    try:
        record = data_model.get_record_by_id(table_name, id_field, id_value)
        if not record:
            return jsonify({'error': 'Record not found'}), 404
        
        children = data_model.get_related_records(table_name, record, 'children')
        parents = data_model.get_related_records(table_name, record, 'parents')
        
        table_info = data_model.get_table_info(table_name)
        
        return render_template('record_view.html',
                             table_name=table_name,
                             table_info=table_info,
                             record=record,
                             children=children,
                             parents=parents)
    except Exception as e:
        logger.error(f"Error viewing record: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/search')
def search():
    try:
        key_field = request.args.get('key_field')
        key_value = request.args.get('key_value')
        
        if not key_field or not key_value:
            return render_template('search.html', results=None)
        
        results = data_model.search_by_key(key_field, key_value)
        
        return render_template('search.html', 
                             results=results,
                             key_field=key_field,
                             key_value=key_value)
    except Exception as e:
        logger.error(f"Error searching: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/trace_signal/<signal_ipid>')
def trace_signal(signal_ipid):
    try:
        trace_results = data_model.trace_signal(signal_ipid)
        
        return render_template('signal_trace.html',
                             signal_ipid=signal_ipid,
                             trace_results=trace_results)
    except Exception as e:
        logger.error(f"Error tracing signal: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/validate/<table_name>/<fqn_id>')
def validate_integrity(table_name, fqn_id):
    try:
        validation_results = data_model.validate_data_integrity(table_name, fqn_id)
        
        return render_template('validation_results.html',
                             table_name=table_name,
                             fqn_id=fqn_id,
                             validation_results=validation_results)
    except Exception as e:
        logger.error(f"Error validating integrity: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/records/<table_name>')
def api_get_records(table_name):
    try:
        filters = {}
        for key in request.args:
            filters[key] = request.args.get(key)
        
        records = data_model.get_records(table_name, filters if filters else None)
        return jsonify(records)
    except Exception as e:
        logger.error(f"API error getting records: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/record/<table_name>/<id_field>/<id_value>')
def api_get_record(table_name, id_field, id_value):
    try:
        record = data_model.get_record_by_id(table_name, id_field, id_value)
        if not record:
            return jsonify({'error': 'Record not found'}), 404
        
        return jsonify(record)
    except Exception as e:
        logger.error(f"API error getting record: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/trace_signal/<signal_ipid>')
def api_trace_signal(signal_ipid):
    try:
        trace_results = data_model.trace_signal(signal_ipid)
        return jsonify(trace_results)
    except Exception as e:
        logger.error(f"API error tracing signal: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/validate/<table_name>/<fqn_id>')
def api_validate_integrity(table_name, fqn_id):
    try:
        validation_results = data_model.validate_data_integrity(table_name, fqn_id)
        return jsonify(validation_results)
    except Exception as e:
        logger.error(f"API error validating integrity: {e}")
        return jsonify({'error': str(e)}), 500

@app.errorhandler(404)
def not_found(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    return render_template('500.html'), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)