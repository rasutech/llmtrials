from flask import Flask, render_template, request, jsonify, redirect, url_for
from data_models_v2 import DataModel
from db_manager_v2 import get_db_manager, close_db_manager
import json
import logging
import atexit

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'

data_model = DataModel()

def cleanup():
    close_db_manager()

atexit.register(cleanup)

@app.route('/')
def index():
    try:
        with open('object_config.json', 'r') as f:
            config = json.load(f)
            tables = list(config['tables'].keys())
        return render_template('index.html', tables=tables)
    except Exception as e:
        logger.error(f"Error loading index: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/search_master/<table_name>')
def search_master_table(table_name):
    try:
        search_value = request.args.get('search_value')
        if not search_value:
            return redirect(url_for('index'))
        
        table_info = data_model.get_table_info(table_name)
        if not table_info:
            return jsonify({'error': f'Table {table_name} not found'}), 404
        
        results = data_model.search_master_table(table_name, search_value)
        
        return render_template('navigation.html', 
                             master_table=table_name,
                             search_value=search_value,
                             results=results,
                             navigation_stack=[])
    except Exception as e:
        logger.error(f"Error searching master table {table_name}: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/navigate/<table_name>/<id_field>/<path:id_value>')
def navigate_relationship(table_name, id_field, id_value):
    try:
        # Get navigation stack from query parameters
        navigation_stack = request.args.getlist('stack')
        
        record = data_model.get_record_by_id(table_name, id_field, id_value)
        if not record:
            return jsonify({'error': 'Record not found'}), 404
        
        # Add current record to navigation stack
        current_item = {
            'table_name': table_name,
            'record': record,
            'display_field': id_field,
            'display_value': id_value
        }
        
        return render_template('navigation.html',
                             current_record=current_item,
                             navigation_stack=navigation_stack,
                             table_name=table_name)
    except Exception as e:
        logger.error(f"Error navigating relationship: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/search')
def search():
    try:
        key_field = request.args.get('key_field')
        key_value = request.args.get('key_value')
        
        if not key_field or not key_value:
            return render_template('search.html', results=None)
        
        results = data_model.search_by_key(key_field, key_value)
        
        return render_template('search.html', 
                             results=results,
                             key_field=key_field,
                             key_value=key_value)
    except Exception as e:
        logger.error(f"Error searching: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/trace_signal/<signal_ipid>')
def trace_signal(signal_ipid):
    try:
        trace_results = data_model.trace_signal(signal_ipid)
        
        return render_template('signal_trace.html',
                             signal_ipid=signal_ipid,
                             trace_results=trace_results)
    except Exception as e:
        logger.error(f"Error tracing signal: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/validate/<table_name>/<fqn_id>')
def validate_integrity(table_name, fqn_id):
    try:
        validation_results = data_model.validate_data_integrity(table_name, fqn_id)
        
        return render_template('validation_results.html',
                             table_name=table_name,
                             fqn_id=fqn_id,
                             validation_results=validation_results)
    except Exception as e:
        logger.error(f"Error validating integrity: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/related/<table_name>/<parent_table>/<parent_field>/<path:parent_value>')
def api_get_related_records(table_name, parent_table, parent_field, parent_value):
    try:
        # Find the relationship configuration
        parent_table_info = data_model.get_table_info(parent_table)
        if not parent_table_info:
            return jsonify({'error': f'Parent table {parent_table} not found'}), 404
        
        relationships = parent_table_info.get('relationships', {}).get('children', [])
        target_relationship = None
        
        for rel in relationships:
            if rel['table'] == table_name:
                target_relationship = rel
                break
        
        if not target_relationship:
            return jsonify({'error': f'No relationship found from {parent_table} to {table_name}'}), 404
        
        # Build filter based on relationship
        filters = {target_relationship['foreign_key']: parent_value}
        records = data_model.get_records(table_name, filters)
        
        return jsonify({
            'parent_table': parent_table,
            'parent_field': parent_field,
            'parent_value': parent_value,
            'child_table': table_name,
            'records': records,
            'relationship': target_relationship
        })
    except Exception as e:
        logger.error(f"API error getting related records: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/record/<table_name>/<id_field>/<id_value>')
def api_get_record(table_name, id_field, id_value):
    try:
        record = data_model.get_record_by_id(table_name, id_field, id_value)
        if not record:
            return jsonify({'error': 'Record not found'}), 404
        
        return jsonify(record)
    except Exception as e:
        logger.error(f"API error getting record: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/trace_signal/<signal_ipid>')
def api_trace_signal(signal_ipid):
    try:
        trace_results = data_model.trace_signal(signal_ipid)
        return jsonify(trace_results)
    except Exception as e:
        logger.error(f"API error tracing signal: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/validate/<table_name>/<fqn_id>')
def api_validate_integrity(table_name, fqn_id):
    try:
        validation_results = data_model.validate_data_integrity(table_name, fqn_id)
        return jsonify(validation_results)
    except Exception as e:
        logger.error(f"API error validating integrity: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/table_info/<table_name>')
def api_get_table_info(table_name):
    try:
        table_info = data_model.get_table_info(table_name)
        if not table_info:
            return jsonify({'error': f'Table {table_name} not found'}), 404
        return jsonify(table_info)
    except Exception as e:
        logger.error(f"API error getting table info: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/database_info')
def api_get_database_info():
    try:
        db_info = data_model.get_database_info()
        return jsonify(db_info)
    except Exception as e:
        logger.error(f"API error getting database info: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/test_connection')
def api_test_connection():
    try:
        test_result = data_model.test_database_connection()
        return jsonify(test_result)
    except Exception as e:
        logger.error(f"API error testing connection: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/validate_config')
def api_validate_config():
    try:
        validation_result = data_model.validate_configuration()
        return jsonify(validation_result)
    except Exception as e:
        logger.error(f"API error validating config: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/config')
def config_management():
    try:
        db_info = data_model.get_database_info()
        test_result = data_model.test_database_connection()
        validation_result = data_model.validate_configuration()
        
        return render_template('config.html',
                             db_info=db_info,
                             test_result=test_result,
                             validation_result=validation_result)
    except Exception as e:
        logger.error(f"Error loading config page: {e}")
        return jsonify({'error': str(e)}), 500

@app.errorhandler(404)
def not_found(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    return render_template('500.html'), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)