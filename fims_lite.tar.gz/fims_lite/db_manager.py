import oracledb
import json
import logging
from typing import Optional, Dict, Any, List
from contextlib import contextmanager
import time

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DatabaseManager:
    def __init__(self, config_file: str = 'db_config.json'):
        self.config_file = config_file
        self.connection_pool = None
        self.config = self._load_config()
        self._initialize_pool()
    
    def _load_config(self) -> Dict[str, Any]:
        try:
            with open(self.config_file, 'r') as f:
                return json.load(f)['database']
        except Exception as e:
            logger.error(f"Failed to load database configuration: {e}")
            raise
    
    def _initialize_pool(self):
        try:
            oracledb.init_oracle_client()
        except:
            logger.info("Oracle client already initialized or thick mode not available")
        
        try:
            self.connection_pool = oracledb.create_pool(
                user=self.config['username'],
                password=self.config['password'],
                dsn=f"{self.config['host']}:{self.config['port']}/{self.config['service_name']}",
                min=self.config.get('min_pool_size', 1),
                max=self.config.get('max_pool_size', 5),
                increment=self.config.get('increment', 1),
                encoding=self.config.get('encoding', 'UTF-8')
            )
            logger.info("Database connection pool initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize connection pool: {e}")
            raise
    
    @contextmanager
    def get_connection(self):
        connection = None
        try:
            connection = self.connection_pool.acquire()
            yield connection
        except oracledb.DatabaseError as e:
            logger.error(f"Database connection error: {e}")
            if connection:
                connection.rollback()
            if self._is_connection_stale(e):
                self._reinitialize_pool()
            raise
        finally:
            if connection:
                self.connection_pool.release(connection)
    
    def _is_connection_stale(self, error) -> bool:
        error_code = error.args[0].code if error.args else None
        stale_error_codes = [3113, 3114, 3135, 12571]
        return error_code in stale_error_codes
    
    def _reinitialize_pool(self):
        logger.info("Reinitializing connection pool...")
        try:
            if self.connection_pool:
                self.connection_pool.close(force=True)
        except:
            pass
        self._initialize_pool()
    
    def execute_query(self, query: str, params: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        max_retries = 3
        retry_delay = 1
        
        for attempt in range(max_retries):
            try:
                with self.get_connection() as connection:
                    cursor = connection.cursor()
                    if params:
                        cursor.execute(query, params)
                    else:
                        cursor.execute(query)
                    
                    columns = [col[0] for col in cursor.description]
                    results = []
                    for row in cursor:
                        results.append(dict(zip(columns, row)))
                    
                    cursor.close()
                    return results
            except Exception as e:
                if attempt < max_retries - 1:
                    logger.warning(f"Query failed (attempt {attempt + 1}), retrying...")
                    time.sleep(retry_delay)
                    retry_delay *= 2
                else:
                    logger.error(f"Query failed after {max_retries} attempts: {e}")
                    raise
    
    def close(self):
        if self.connection_pool:
            self.connection_pool.close()
            logger.info("Database connection pool closed")

db_manager = None

def get_db_manager():
    global db_manager
    if db_manager is None:
        db_manager = DatabaseManager()
    return db_manager

def close_db_manager():
    global db_manager
    if db_manager:
        db_manager.close()
        db_manager = None