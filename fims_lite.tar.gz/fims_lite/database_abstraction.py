import json
import logging
from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional, Tuple
from urllib.parse import quote_plus

logger = logging.getLogger(__name__)

class DatabaseDialect(ABC):
    """Abstract base class for database dialects"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.identifier_quote = config.get('identifier_quote', '"')
        self.identifier_quote_end = config.get('identifier_quote_end', self.identifier_quote)
        self.parameter_style = config.get('parameter_style', 'named')
        self.limit_syntax = config.get('limit_syntax', 'limit_offset')
    
    @abstractmethod
    def build_connection_string(self, db_config: Dict[str, Any]) -> str:
        """Build database-specific connection string"""
        pass
    
    @abstractmethod
    def get_driver_module(self) -> str:
        """Get the driver module name"""
        pass
    
    def quote_identifier(self, identifier: str) -> str:
        """Quote database identifiers (table names, column names)"""
        return f"{self.identifier_quote}{identifier}{self.identifier_quote_end}"
    
    def format_parameter(self, param_name: str, param_index: int = 0) -> str:
        """Format parameter based on database parameter style"""
        if self.parameter_style == 'named':
            return f":{param_name}"
        elif self.parameter_style == 'pyformat':
            return f"%({param_name})s"
        elif self.parameter_style == 'qmark':
            return "?"
        else:
            return f":{param_name}"
    
    def build_limit_clause(self, limit: int, offset: int = 0) -> str:
        """Build database-specific LIMIT clause"""
        if self.limit_syntax == 'limit_offset':
            if offset > 0:
                return f"LIMIT {limit} OFFSET {offset}"
            return f"LIMIT {limit}"
        elif self.limit_syntax == 'rownum':
            if offset > 0:
                return f"WHERE ROWNUM BETWEEN {offset + 1} AND {offset + limit}"
            return f"WHERE ROWNUM <= {limit}"
        elif self.limit_syntax == 'first_skip':
            if offset > 0:
                return f"FIRST {limit} SKIP {offset}"
            return f"FIRST {limit}"
        elif self.limit_syntax == 'top_offset':
            # SQL Server style
            if offset > 0:
                return f"OFFSET {offset} ROWS FETCH NEXT {limit} ROWS ONLY"
            return f"TOP {limit}"
        else:
            return f"LIMIT {limit}"
    
    def build_select_query(self, table_name: str, schema: str = None, 
                          columns: List[str] = None, filters: Dict[str, Any] = None,
                          limit: int = None, offset: int = 0) -> Tuple[str, Dict[str, Any]]:
        """Build SELECT query with database-specific syntax"""
        
        # Build column list
        if columns:
            column_str = ', '.join([self.quote_identifier(col) for col in columns])
        else:
            column_str = '*'
        
        # Build table name with schema
        if schema:
            full_table_name = f"{self.quote_identifier(schema)}.{self.quote_identifier(table_name)}"
        else:
            full_table_name = self.quote_identifier(table_name)
        
        # Start building query
        if self.limit_syntax == 'top_offset' and limit and offset == 0:
            query = f"SELECT TOP {limit} {column_str} FROM {full_table_name}"
        else:
            query = f"SELECT {column_str} FROM {full_table_name}"
        
        # Build WHERE clause
        params = {}
        if filters:
            where_clauses = []
            for i, (key, value) in enumerate(filters.items()):
                quoted_key = self.quote_identifier(key)
                if value is not None:
                    param_name = f"param_{i}"
                    if self.parameter_style == 'qmark':
                        where_clauses.append(f"{quoted_key} = ?")
                    else:
                        where_clauses.append(f"{quoted_key} = {self.format_parameter(param_name)}")
                    params[param_name] = value
                else:
                    where_clauses.append(f"{quoted_key} IS NULL")
            
            if where_clauses:
                query += " WHERE " + " AND ".join(where_clauses)
        
        # Add LIMIT clause
        if limit and self.limit_syntax not in ['top_offset', 'rownum']:
            query += " " + self.build_limit_clause(limit, offset)
        elif limit and self.limit_syntax == 'rownum':
            # Oracle ROWNUM handling - needs to be wrapped
            if offset > 0:
                query = f"SELECT * FROM ({query}) WHERE ROWNUM BETWEEN {offset + 1} AND {offset + limit}"
            else:
                query = f"SELECT * FROM ({query}) WHERE ROWNUM <= {limit}"
        elif limit and self.limit_syntax == 'top_offset' and offset > 0:
            query += f" ORDER BY 1 {self.build_limit_clause(limit, offset)}"
        
        return query, params


class OracleDialect(DatabaseDialect):
    """Oracle database dialect"""
    
    def build_connection_string(self, db_config: Dict[str, Any]) -> str:
        username = quote_plus(db_config.get('username', ''))
        password = quote_plus(db_config.get('password', ''))
        host = db_config.get('host', 'localhost')
        port = db_config.get('port', 1521)
        service_name = db_config.get('service_name', 'ORCL')
        
        return f"oracle+cx_oracle://{username}:{password}@{host}:{port}/?service_name={service_name}"
    
    def get_driver_module(self) -> str:
        return "cx_Oracle"


class PostgreSQLDialect(DatabaseDialect):
    """PostgreSQL database dialect"""
    
    def build_connection_string(self, db_config: Dict[str, Any]) -> str:
        username = quote_plus(db_config.get('username', ''))
        password = quote_plus(db_config.get('password', ''))
        host = db_config.get('host', 'localhost')
        port = db_config.get('port', 5432)
        database = db_config.get('database', 'postgres')
        
        return f"postgresql://{username}:{password}@{host}:{port}/{database}"
    
    def get_driver_module(self) -> str:
        return "psycopg2"


class InformixDialect(DatabaseDialect):
    """Informix database dialect"""
    
    def build_connection_string(self, db_config: Dict[str, Any]) -> str:
        username = quote_plus(db_config.get('username', ''))
        password = quote_plus(db_config.get('password', ''))
        host = db_config.get('host', 'localhost')
        port = db_config.get('port', 9088)
        database = db_config.get('database', 'informix')
        
        return f"informix://{username}:{password}@{host}:{port}/{database}"
    
    def get_driver_module(self) -> str:
        return "informixdb"


class MySQLDialect(DatabaseDialect):
    """MySQL database dialect"""
    
    def build_connection_string(self, db_config: Dict[str, Any]) -> str:
        username = quote_plus(db_config.get('username', ''))
        password = quote_plus(db_config.get('password', ''))
        host = db_config.get('host', 'localhost')
        port = db_config.get('port', 3306)
        database = db_config.get('database', 'mysql')
        
        return f"mysql+pymysql://{username}:{password}@{host}:{port}/{database}"
    
    def get_driver_module(self) -> str:
        return "pymysql"


class SQLServerDialect(DatabaseDialect):
    """SQL Server database dialect"""
    
    def build_connection_string(self, db_config: Dict[str, Any]) -> str:
        username = quote_plus(db_config.get('username', ''))
        password = quote_plus(db_config.get('password', ''))
        host = db_config.get('host', 'localhost')
        port = db_config.get('port', 1433)
        database = db_config.get('database', 'master')
        
        return f"mssql+pyodbc://{username}:{password}@{host}:{port}/{database}?driver=ODBC+Driver+17+for+SQL+Server"
    
    def get_driver_module(self) -> str:
        return "pyodbc"


class DatabaseAbstraction:
    """Main database abstraction class"""
    
    DIALECTS = {
        'oracle': OracleDialect,
        'postgresql': PostgreSQLDialect,
        'informix': InformixDialect,
        'mysql': MySQLDialect,
        'sqlserver': SQLServerDialect
    }
    
    def __init__(self, config_file: str = 'database_config.json'):
        self.config = self._load_config(config_file)
        self.db_config = self.config['database']
        self.db_type = self.db_config['type'].lower()
        
        if self.db_type not in self.DIALECTS:
            raise ValueError(f"Unsupported database type: {self.db_type}")
        
        # Get dialect-specific configuration
        dialect_config = self.config['supported_databases'][self.db_type]
        
        # Initialize dialect
        self.dialect = self.DIALECTS[self.db_type](dialect_config)
        
    def _load_config(self, config_file: str) -> Dict[str, Any]:
        """Load database configuration"""
        try:
            with open(config_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Failed to load database configuration: {e}")
            raise
    
    def get_connection_string(self) -> str:
        """Get database connection string"""
        return self.dialect.build_connection_string(self.db_config)
    
    def get_driver_module(self) -> str:
        """Get database driver module name"""
        return self.dialect.get_driver_module()
    
    def get_default_schema(self) -> str:
        """Get default schema name"""
        return self.db_config.get('default_schema', '')
    
    def build_select_query(self, table_name: str, schema: str = None,
                          columns: List[str] = None, filters: Dict[str, Any] = None,
                          limit: int = None, offset: int = 0) -> Tuple[str, Dict[str, Any]]:
        """Build SELECT query using dialect-specific syntax"""
        if schema is None:
            schema = self.get_default_schema()
        
        return self.dialect.build_select_query(
            table_name=table_name,
            schema=schema,
            columns=columns,
            filters=filters,
            limit=limit,
            offset=offset
        )
    
    def validate_connection_config(self) -> Dict[str, Any]:
        """Validate database connection configuration"""
        validation_result = {
            'valid': True,
            'errors': [],
            'warnings': []
        }
        
        required_fields = ['type', 'host', 'username', 'password']
        
        for field in required_fields:
            if field not in self.db_config or not self.db_config[field]:
                validation_result['valid'] = False
                validation_result['errors'].append(f"Missing required field: {field}")
        
        # Database-specific validations
        if self.db_type == 'oracle':
            if 'service_name' not in self.db_config:
                validation_result['warnings'].append("Oracle service_name not specified, using default 'ORCL'")
        elif self.db_type in ['postgresql', 'mysql', 'informix', 'sqlserver']:
            if 'database' not in self.db_config:
                validation_result['errors'].append("Database name is required for this database type")
        
        return validation_result
    
    def get_database_info(self) -> Dict[str, Any]:
        """Get database configuration information"""
        return {
            'type': self.db_type,
            'dialect': self.dialect.__class__.__name__,
            'driver': self.get_driver_module(),
            'default_schema': self.get_default_schema(),
            'parameter_style': self.dialect.parameter_style,
            'limit_syntax': self.dialect.limit_syntax,
            'identifier_quote': self.dialect.identifier_quote
        }