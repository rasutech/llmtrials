# FIMS Lite - Fiber Inventory Management Support Tool

A lightweight web application for troubleshooting and validating data integrity in fiber inventory management systems.

## Features

- **Data Lookup**: Fast search across all tables using various key fields (IPID, FQN_ID, GLOBALID, etc.)
- **Relationship Navigation**: Click-through navigation between related records
- **Signal Tracing**: Comprehensive signal path tracing across splice, fiber, and port records
- **Data Integrity Validation**: Automated validation of referential integrity and required fields
- **RESTful API**: JSON API endpoints for programmatic access
- **Single Connection Pool**: Efficient database connection management with automatic reconnection

## Prerequisites

- Python 3.8+
- Oracle Database (or Oracle Instant Client)
- Network access to your Oracle database

## Installation

1. Clone or download this repository:
```bash
cd /Users/thamaraiselvi/sandbox/fims_lite
```

2. Install Python dependencies:
```bash
pip install -r requirements.txt
```

3. Configure database connection:
   - Edit `db_config.json` with your Oracle database credentials:
```json
{
  "database": {
    "host": "your_host",
    "port": 1521,
    "service_name": "your_service",
    "username": "your_username",
    "password": "your_password"
  }
}
```

4. (Optional) Install Oracle Instant Client if not already installed:
   - Download from Oracle website
   - Set environment variables as needed

## Running the Application

Start the Flask development server:
```bash
python app.py
```

The application will be available at: `http://localhost:5000`

## Usage

### Web Interface

1. **Home Page**: Quick access to all major features
2. **Search**: Search any field across all tables
3. **Table Views**: Browse and filter records in each table
4. **Record Details**: View individual records with related data
5. **Signal Trace**: Trace signal paths through the network
6. **Data Validation**: Validate data integrity for specific records

### API Endpoints

- `GET /api/records/<table_name>` - Get all records from a table
- `GET /api/record/<table_name>/<id_field>/<id_value>` - Get specific record
- `GET /api/trace_signal/<signal_ipid>` - Trace signal connections
- `GET /api/validate/<table_name>/<fqn_id>` - Validate data integrity

### Key Features

#### Hyperlink Navigation
- Click on any IPID, SIGNALIPID, SEGMENTID, etc. to navigate to related records
- Automatic detection of relationship fields

#### Data Integrity Validation
- Checks for NULL values in required fields
- Verifies foreign key relationships exist
- Reports orphaned records and broken references
- Counts dependent records

#### Signal Tracing
- Shows all fiber splices, fibers, and ports for a signal
- Displays complete signal path information
- Links to all related equipment and cable records

## Configuration

### Adding New Tables

Edit `object_config.json` to add new table definitions:
```json
{
  "tables": {
    "NEW_TABLE": {
      "table_name": "NEW_TABLE",
      "description": "Description",
      "primary_keys": ["OBJECTID"],
      "fields": {...},
      "relationships": {...}
    }
  }
}
```

### Database Connection Settings

The connection pool can be configured in `db_config.json`:
- `min_pool_size`: Minimum connections (default: 1)
- `max_pool_size`: Maximum connections (default: 5)
- `increment`: Connection increment (default: 1)

## Troubleshooting

### Connection Issues
- The application automatically reconnects on stale connections
- Check Oracle client installation if thick mode errors occur
- Verify network access to database server

### Performance
- Adjust connection pool size based on usage
- Use filters to limit result sets
- API endpoints support pagination parameters

## Architecture

- **Flask**: Web framework
- **oracledb**: Oracle database driver with connection pooling
- **Single Connection**: One persistent connection pool for entire application lifecycle
- **Dynamic Queries**: No hardcoded SQL, all queries built from configuration

## Security Notes

- Store database credentials securely
- Use environment variables for production deployments
- Implement authentication/authorization as needed
- Review and restrict database user permissions

## Development

To extend the application:
1. Add new tables to `object_config.json`
2. Extend `data_models.py` for custom logic
3. Add new routes in `app.py`
4. Create corresponding templates in `templates/`

## License

For internal use only.